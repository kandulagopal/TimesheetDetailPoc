import { Component } from '@angular/core';
import { TimeSheetDetailsInfo } from './model/TimeSheetDetail.model';
import { TimeSheetDetailService } from './services/TimeSheetDetails.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ClientApp';
  TimeSheetDetailInfo: TimeSheetDetailsInfo = new TimeSheetDetailsInfo();
  //SaveTimeSheetDetails() {
  //  //alert(22);
  //  //console.log(this.TimeSheetDetailInfo.Date);
  //}
  constructor(private _TimeSheetDetailsService: TimeSheetDetailService) {

  }
  SaveTimeSheetDetails() {
    this._TimeSheetDetailsService.SaveTimeSheetDetails(this.TimeSheetDetailInfo)
      .subscribe(data => {
        if (data > 0) { //success

        }
      });
  }
}
