import { Injectable, Inject } from '@angular/core';
//import { Router } from '@angular/router';
//import 'rxjs/add/operator/map';
//import 'rxjs/add/operator/catch';
//import 'rxjs/add/observable/throw';
import { TimeSheetDetailsInfo } from '../model/TimeSheetDetail.model';
import { HttpClient, HttpHeaders  } from '@angular/common/http';
//import { Observable } from 'rxjs';
const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/xml',
    //'Authorization': 'jwt-token'
  })
}; 
@Injectable()
export class TimeSheetDetailService {
  constructor(private _http: HttpClient) {
  }

  SaveTimeSheetDetails(timesheetdetails: TimeSheetDetailsInfo) {
    return this._http.post('/api/TimeSheeDetails/SaveTimeSheetDetails', timesheetdetails, httpOptions)
  }

  SaveTimeSheetDetails1(timesheetdetails: TimeSheetDetailsInfo) {
    return this._http.get('/api/TimeSheeDetails/GetData');
  }
}
