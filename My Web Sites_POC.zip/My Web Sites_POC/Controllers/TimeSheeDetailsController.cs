﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using BusinessLogic;
using Common.Model;

namespace My_Web_Sites_POC.Controllers
{
    //[Route("api/[controller]")]
    //[ApiController]
    public class TimeSheeDetailsController : ControllerBase
    {


        // POST api/values
        [HttpPost]
        [Route("api/TimeSheeDetails/SaveTimeSheetDetails")]
        public IActionResult SaveTimeSheetDetails(TimeSheetDetailsInfo timeSheetDetailInf)
        {
            BalTimeSheetDetails obj = new BalTimeSheetDetails();
            return new OkObjectResult (obj.SaveTimeSheetDetails(timeSheetDetailInf));
        }

        [HttpGet]
        [Route("api/TimeSheeDetails/GetData")]
        public IActionResult GetData()
        {
            return new OkResult();
        }

    }
}
