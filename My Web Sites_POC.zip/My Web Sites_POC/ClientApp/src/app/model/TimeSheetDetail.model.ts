export interface ITimeSheetDetailsInfo {

  Date: string;
  HoursWorked: number;
}

export class TimeSheetDetailsInfo implements ITimeSheetDetailsInfo {
  constructor(
    public Date: string="",
    public HoursWorked: number=null

  ) { }
}
